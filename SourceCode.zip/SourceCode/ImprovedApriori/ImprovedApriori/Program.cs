﻿/*
 * Author : Arun Athisamy 
 * ID : B00762770
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
//using System.Windows.Forms.DataVisualization.Charting;

namespace ImprovedApriori
{
    #region Business Logic
    /// <summary>
    /// Main class of Apriori Algorithm
    /// </summary>
    public class Program
    {
        /// <summary>
        /// List contains all the attributes and its unique item
        /// </summary>
        public Dictionary<string, string> valueAttrList;

        /// <summary>
        /// Contains the TransactionID of each itemset
        /// </summary>
        Dictionary<string, List<int>> TrasactionID = new Dictionary<string, List<int>>();

        /// <summary>
        /// Contains the TransactionID of only frequent itemset
        /// </summary>
        Dictionary<string, List<int>> FrequentItemSetTransID = new Dictionary<string, List<int>>();

        /// <summary>
        /// Main method of Apriori algorithm
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            try
            {
                int noOfTransactions = 0;
                Console.WriteLine("Please enter the dataset name with out format?");
                string file = Console.ReadLine();
                string path = System.IO.Directory.GetCurrentDirectory();
                if (File.Exists(path + "\\" + file + ".csv"))
                {
                    //List<Itemset> Data = new List<Itemset>();
                    DataTable Data = new DataTable();
                    Program p = new Program();
                    Console.WriteLine("Data Loading started ...");
                    Data = p.LoadDB(path + "\\" + file + ".csv");
                    noOfTransactions = Data.Rows.Count;
                    Console.WriteLine("Data Loading completed ...");

                    Console.WriteLine("Please enter the support rate 0.0-1.0?");
                    double min_support = Convert.ToDouble(Console.ReadLine());
                    if (min_support > 1.0)
                    {
                        throw new InvalidOperationException();
                    }
                    Console.WriteLine("Please enter the Confidence rate 0.0-1.0?");
                    double min_confidence = Convert.ToDouble(Console.ReadLine());
                    if (min_confidence > 1.0)
                    {
                        throw new InvalidOperationException();
                    }
                    Stopwatch stopWatch = new Stopwatch();
                    stopWatch.Start();
                    Console.WriteLine("Generating 1 frequent Itemset started ...");
                    Dictionary<string, int> C1 = p.generateCandidate1Itemset(Data);
                    Dictionary<string, int> I1 = p.generateFrequent1ItemSet(C1, min_support, noOfTransactions);
                    p.TrimCandidateItemsetOfTransactionID(I1);
                    Console.WriteLine("Generating 1 frequent Itemset Completed ...");

                    Console.WriteLine("Generating K frequent Itemset started ...");
                    Dictionary<int, Dictionary<string, double>> a = p.generateFrequentKItemSet(I1, min_support, Data, noOfTransactions);
                    Console.WriteLine("Generating K frequent Itemset Completed ...");

                    Console.WriteLine("Generating Rules ...");
                    List<ResultClass> FinalResults = p.GenerateAssociationRule(a, min_support, min_confidence, Data, noOfTransactions);
                    stopWatch.Stop();
                    TimeSpan ts = stopWatch.Elapsed;
                    string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",ts.Hours, ts.Minutes, ts.Seconds,ts.Milliseconds / 10);
                    Console.Write("Time" + elapsedTime +"\n");
                    p.PrintRules(FinalResults, min_support, min_confidence, Data.Rows.Count, elapsedTime);
                    Console.WriteLine("Rule generation completed ...");
                    Console.Read();
                }
                else
                {
                    throw new FileNotFoundException();
                }
            }
            catch (InvalidOperationException InvalidEx)
            {
                Console.WriteLine("Please retry by entering Support/Confidence between 0.0-1.0");
                Console.Read();
            }
            catch (FileNotFoundException fileNotFoundEx)
            {
                Console.WriteLine("Entered Dataset is not present in the current directory. Please retry dataset name after importing the dataset to the current directory");
                Console.Read();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occurred while running the program");
                Console.Read();
            }

        }

        /// <summary>
        /// Loads the given Data set
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns>List of Itemset(Data rows)</returns>
        public DataTable LoadDB(string fileName)
        {

            List<Itemset> data = new List<Itemset>();
            List<DataRows> Rows = new List<DataRows>();
            DataTable dataTable = new DataTable();

            string[] head = null;
            if (File.Exists(fileName))
            {
                StreamReader sr = new StreamReader(File.OpenRead(fileName), Encoding.Default, true);
                string row = "";
                int k = 0;
                while (!sr.EndOfStream)
                {
                    k++;
                    row = sr.ReadLine();


                    string[] cols = Regex.Replace(row, @"\s+", " ").Split(" +".ToCharArray());
                    //Get the headers
                    if (k == 1)
                    {
                        for (int i = 0; i < cols.Length; i++)
                        {
                            dataTable.Columns.Add(cols[i]);
                        }
                    }
                    else
                    {
                        if (cols[0].ToString() != "")
                        {
                            //Reading datarows                            
                            dataTable.Rows.Add(cols);
                        }
                    }
                }
                sr.Close();
            }
            return dataTable;
        }

        ///// <summary>
        ///// Loads the given Data set
        ///// </summary>
        ///// <param name="fileName"></param>
        ///// <returns>List of Itemset(Data rows)</returns>
        //public List<Itemset> LoadDB(string fileName)
        //{

        //    List<Itemset> data = new List<Itemset>();
        //    List<DataRows> Rows = new List<DataRows>();

        //    string[] head = null;
        //    if (File.Exists(fileName))
        //    {
        //        StreamReader sr = new StreamReader(File.OpenRead(fileName), Encoding.Default, true);
        //        string row = "";
        //        int k = 0;
        //        while (!sr.EndOfStream)
        //        {
        //            k++;
        //            row = sr.ReadLine();

        //            string[] cols = Regex.Replace(row, @"\s+", " ").Split(" ".ToCharArray());
        //            //Get the headers
        //            if (k == 1)
        //            {
        //                head = cols;
        //            }
        //            else
        //            {
        //                //Reading datarows
        //                Itemset Itemset = new Itemset();
        //                Itemset.Item = new List<DataRows>();
        //                for (int i = 1; i < cols.Length + 1; i++)
        //                {
        //                    Itemset.Item.Add(new DataRows(i.ToString() + "." + (k - 1).ToString(), head[i - 1], cols[i - 1]));
        //                }
        //                data.Add(Itemset);
        //            }
        //        }
        //        sr.Close();
        //    }
        //    return data;
        //}

        /// <summary>
        /// This method is used to generate 1-candidate item set 
        /// </summary>
        /// <param name="Data"></param>
        /// <returns>Dictionary of candidate 1-itemsets</returns>
        public Dictionary<string, int> generateCandidate1Itemset(DataTable Data)
        {
            //Generating unique itemset and adding to a dictionary 
            Dictionary<string, int> result = new Dictionary<string, int>();            
            valueAttrList = new Dictionary<string, string>();
            for(int i=0;i<Data.Rows.Count;i++)
            {
                for(int j=0;j<Data.Columns.Count;j++)
                {
                    int value;
                    List<int> trans;
                    var key = Data.Rows[i].Field<string>(j);
                    if (result.TryGetValue(key, out value))
                    {
                        result[key] = value + 1;
                        if(TrasactionID.TryGetValue(key,out trans))
                        {
                            trans.Add(i);
                            TrasactionID[key] = trans;
                        }
                    }
                    else
                    {
                        List<int> transactionId = new List<int>();
                        result.Add(key, 1);
                        transactionId.Add(i);
                        TrasactionID.Add(key, transactionId);
                        valueAttrList.Add(Data.Rows[i].Field<string>(j), Data.Columns[j].ToString());
                    }
                }
            }
           
            return result;
        }

        /// <summary>
        /// This method used to generate 1-frequent Itemset
        /// </summary>
        /// <param name="c1"></param>
        /// <param name="min_support"></param>
        /// <param name="noOfTransactions"></param>
        /// <returns>Dictionary of frequent 1-itemsets</returns>
        public Dictionary<string, int> generateFrequent1ItemSet(Dictionary<string, int> c1, double min_support, int noOfTransactions)
        {
            //Prunning 1-frequent itemset
            Dictionary<string, int> FrequentItemSet1 = new Dictionary<string, int>();
            foreach (var Item in c1)
            {
                double support = Convert.ToDouble(Item.Value) / Convert.ToDouble(noOfTransactions);
                if (support > min_support)
                {
                    FrequentItemSet1.Add(Item.Key, Item.Value);
                }
            }
            return FrequentItemSet1;
        }

        /// <summary>
        /// This method used to Transaction ID of frequent Itemset
        /// </summary>
        /// <param name="I1"></param>       
        /// <returns>Dictionary of Transaction ID of frequent itemsets</returns>
        public void TrimCandidateItemsetOfTransactionID(Dictionary<string, int> I1)
        {                       
            foreach (var Item in I1)
            {
                foreach(var id in TrasactionID)
                {
                    if (Item.Key == id.Key)
                    {
                        FrequentItemSetTransID.Add(id.Key,id.Value);
                    }
                }                
            }           
        }

        /// <summary>
        /// This method used to generate K frequent itemset
        /// </summary>
        /// <param name="FrequentItemsetm"></param>
        /// <param name="min_support"></param>
        /// <param name="Data"></param>
        /// <param name="noOfTransactions"></param>
        /// <returns>This method returns Dictionary that holds frequent itemset of k</returns>
        public Dictionary<int, Dictionary<string, double>> generateFrequentKItemSet(Dictionary<string, int> FrequentItemsetm, double min_support, DataTable Data, int noOfTransactions)
        {
            Dictionary<int, Dictionary<string, double>> result = new Dictionary<int, Dictionary<string, double>>();
            List<List<string>> frequentMItemset = new List<List<string>>();
            List<List<string>> candKItemsets = new List<List<string>>();
            List<string> dictToList = new List<string>();
            Dictionary<string, double> resultsubset = new Dictionary<string, double>();

            //convert 1-frequent itemset dictionary to a list
            foreach (KeyValuePair<string, int> pair in FrequentItemsetm)
            {
                dictToList.Add(pair.Key);
            }
            frequentMItemset.Add(dictToList);
            int k = 2;
            //Looping to find k frequent itemset
            while (!(frequentMItemset.Count == 0))
            {
                ArrayList List1 = new ArrayList();

                candKItemsets = generateCandidateKItemset(frequentMItemset, k);
                frequentMItemset = new List<List<string>>();
                resultsubset = new Dictionary<string, double>();

                //Convert candidate itemset in to list
                foreach (var itemList in candKItemsets)
                {
                    foreach (var itemSubset in itemList)
                    {
                        List1.Add(itemSubset);
                    }
                }

                //Converting datarows in to a list for easy computation
                List<List<string>> datarows = new List<List<string>>();
                //foreach (var data in Data)
                //{
                //    if (data != null && data?.Item.Count > 0)
                //    {
                //        List<string> datarow = new List<string>();
                //        foreach (var dr in data.Item)
                //        {
                //            datarow.Add(dr.ValueName);
                //        }
                //        datarows.Add(datarow);
                //    }

                //}

                //Check the support of each candidate itemset and prune before adding to frequent item set dictionary
                for (int i = 0; i < List1.Count; i++)
                {
                    Dictionary<string, List<int>> newtemp = new Dictionary<string, List<int>>();
                    string[] uniqueItems = List1[i].ToString().Split(' ');
                    List<string> Subset1 = uniqueItems.ToList();
                    List<int> TID = new List<int>();
                    int max = Data.Rows.Count;
                    foreach (var item in Subset1)
                    {                        
                        if (FrequentItemSetTransID[item].Count < max)
                        {
                            max = FrequentItemSetTransID[item].Count;
                            TID = FrequentItemSetTransID[item];
                        }
                    }
                    int presence = 0;

                    foreach (var Tid in TID)
                    {
                        string[] TempTrans = new string[Data.Rows[Tid].ItemArray.Length];
                        List<object> copy = new List<object>();
                        copy = Data.Rows[Tid].ItemArray.ToList();
                        //copy.Add(Data.Rows[Tid].ToString());
                        copy = copy.Intersect(Subset1).ToList();
                        if (copy.Count == Subset1.Count)
                        {
                            presence++;
                        }
                    }

                    //Prunning itemset before adding to the frequent itemset list
                    double support = Convert.ToDouble(presence) / Convert.ToDouble(noOfTransactions);
                    if (support > min_support)
                    {
                        List<string> L2 = new List<string>();
                        List<string> L = new List<string>();
                        if (Subset1.Count > 0)
                        {
                            string aab = string.Join(" ", Subset1);
                            L.Add(aab);
                            resultsubset.Add(aab, support);
                        }
                        frequentMItemset.Add(L);
                    }
                }
                if (frequentMItemset != null && frequentMItemset.Count > 0)
                {
                    result.Add(k, resultsubset);
                }
                k = k + 1;
            }


            return result;
        }

        /// <summary>
        /// This method  used to generate k-candidate itemset
        /// </summary>
        /// <param name="FrequentItemsetm"></param>
        /// <param name="m"></param>
        /// <returns>returns List of all candidate itemset of particular k value</returns>
        public List<List<string>> generateCandidateKItemset(List<List<string>> FrequentItemsetm, int m)
        {
            Dictionary<int, Dictionary<string, int>> result = new Dictionary<int, Dictionary<string, int>>();
            Dictionary<string, int> tempDict = new Dictionary<string, int>();
            List<List<string>> resultSubset = new List<List<string>>();
            List<List<string>> dupFrequentItemsetm = new List<List<string>>(FrequentItemsetm);
            bool isExisting = false;
            ArrayList List1 = new ArrayList();
            ArrayList List2 = new ArrayList();
            List<string> L = new List<string>();
            List<string> L2 = new List<string>();

            //Make two lists from two frequent itemset dictionaries
            foreach (var itemList in FrequentItemsetm)
            {
                foreach (var itemSubset in itemList)
                {
                    List1.Add(itemSubset);
                }
            }
            foreach (var itemList in dupFrequentItemsetm)
            {
                foreach (var itemSubset in itemList)
                {
                    List2.Add(itemSubset);
                }
            }

            //Generate candidate itemset
            for (int i = 0; i < List1.Count; i++)
            {
                string[] uniqueItems = List1[i].ToString().Split(' ');
                List<string> Subset1 = uniqueItems.ToList();
                for (int j = i + 1; j < List2.Count; j++)
                {
                    string[] resut = new string[100];
                    string[] uniqueItems2 = List2[j].ToString().Split(' ');
                    List<string> Subset2 = uniqueItems2.ToList();
                    List<string> resultMerge = generateCandiateItemSetFromTwoSubsets(Subset1, Subset2);
                    if (resultMerge.Count > 0)
                    {
                        isExisting = false;
                        if (L != null && L?.Count > 0)
                        {
                            for (int M = 0; M < L.Count; M++)
                            {
                                string[] sepString = L[M].ToString().Split(' ');
                                List<string> listSepString = sepString.ToList();
                                L2 = listSepString.Intersect(resultMerge).ToList();
                                if (L2.Count == resultMerge.Count)
                                {
                                    isExisting = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            isExisting = false;
                        }
                        if (!isExisting)
                        {
                            string aab = string.Join(" ", resultMerge);
                            L.Add(aab);
                        }
                    }
                }
            }
            resultSubset.Add(L);
            return resultSubset;
        }

        /// <summary>
        /// Joining two subsets
        /// </summary>
        /// <param name="ItemsetA"></param>
        /// <param name="ItemsetB"></param>
        /// <returns>List of combined Itemset</returns>
        public List<string> generateCandiateItemSetFromTwoSubsets(List<string> ItemsetA, List<string> ItemsetB)
        {
            List<string> result = new List<string>();
            int i = 1;
            int size = ItemsetA.Count();
            List<string> ItemsetA1 = new List<string>(ItemsetA);
            ItemsetA = ItemsetA.Intersect(ItemsetB).ToList();
            if (ItemsetA.Count == size - i)
            {
                foreach (var item in ItemsetA1)
                {
                    result.Add(item);
                }
                foreach (var item in ItemsetB)
                {
                    result.Remove(item);
                }
                foreach (var item in ItemsetB)
                {
                    result.Add(item);
                }
            }

            return result;
        }

        /// <summary>
        /// This method is used for generating association rules
        /// </summary>
        /// <param name="frquentKItemset"></param>
        /// <param name="min_support"></param>
        /// <param name="min_confidence"></param>
        /// <param name="Data"></param>
        /// <param name="noOfTransaction"></param>
        /// <returns>List of Result Class(Rules)</returns>
        public List<ResultClass> GenerateAssociationRule(Dictionary<int, Dictionary<string, double>> frquentKItemset, double min_support, double min_confidence, DataTable Data, int noOfTransaction)
        {
            var last = frquentKItemset.Values.Last();
            List<ResultClass> FinalResults = new List<ResultClass>();
            List<List<string>> datarows = new List<List<string>>();
            //Converting data to list
            //foreach (var data in Data)
            //{
            //    if (data != null && data?.Item.Count > 0)
            //    {
            //        List<string> datarow = new List<string>();
            //        foreach (var dr in data.Item)
            //        {
            //            datarow.Add(dr.ValueName);
            //        }
            //        datarows.Add(datarow);
            //    }

            //}
            //Generate rules for each frequent itemsets from k=2
            foreach (var kitemset in frquentKItemset)
            {
                foreach (var pair in kitemset.Value)
                {
                    List<List<string>> subsetList = new List<List<string>>();
                    string uniqueItems = pair.Key;
                    string[] subset = uniqueItems.Split(' ');
                    // Referred from : http://stackoverflow.com/questions/999050/how-to-get-all-subsets-of-an-array               
                    //Getting Subset of the parent Itemset
                    foreach (var strings in GetSubsets(subset))
                    {
                        List<string> innerset = new List<string>();
                        var temp = strings.ToArray();
                        for (int i = 0; i < temp.Count(); i++)
                        {
                            if (temp[i] != null || !string.IsNullOrWhiteSpace(temp[i]))
                            {
                                innerset.Add(temp[i]);
                            }
                        }

                        if (innerset.Count > 0)
                        {
                            int presence = 0;
                            for(int i =0;i< Data.Rows.Count; i++)
                            {                                
                                List<object> copy = new List<object>();
                                copy = Data.Rows[i].ItemArray.ToList();                                
                                copy = copy.Intersect(innerset).ToList();                                
                                if (copy.Count == innerset.Count)
                                {
                                    presence++;
                                }
                            }

                            //Selecting strong confidence
                            double confidence = pair.Value / (Convert.ToDouble(presence) / Convert.ToDouble(noOfTransaction));
                            if (confidence >= min_confidence)
                            {
                                List<string> tempList = new List<string>();
                                List<string> tempList2 = new List<string>();
                                ResultClass results = new ResultClass();
                                results.support = (Convert.ToDouble(presence) / Convert.ToDouble(noOfTransaction));
                                results.confidence = confidence;
                                results.product = innerset;
                                results.recommends = new List<string>();
                                tempList = subset.ToList();
                                tempList2 = tempList.Intersect(innerset).ToList();
                                foreach (var set in tempList2)
                                {
                                    if (tempList.Contains(set))
                                    {
                                        tempList.Remove(set);
                                    }
                                }
                                results.recommends = tempList;
                                FinalResults.Add(results);
                            }
                        }
                    }
                }
            }


            return FinalResults;
        }

        /// <summary>
        /// This method is used to print the List of rules to the output file
        /// </summary>
        /// <param name="FinalResult"></param>
        public void PrintRules(List<ResultClass> FinalResult, double min_support, double min_conf, int dataCount, string Time)
        {
            string path = System.IO.Directory.GetCurrentDirectory();
            using (StreamWriter file = new StreamWriter(path + "\\output.txt"))
            {
                file.WriteLine("Summary:\n");
                file.WriteLine("Total rows in the original set: {0}\n", dataCount);
                file.WriteLine("The selected measures: Support = {0} Confidendence = {1}\n", min_support, min_conf);
                file.WriteLine("--------------------------------------------------------------------");
                file.WriteLine("Association Rules are as follows:");
                int rulecount = 0;
                foreach (var entry in FinalResult)
                {
                    if (entry?.recommends?.Count > 0)
                    {
                        List<string> prodList = new List<string>();
                        List<string> recommendationList = new List<string>();
                        rulecount++;
                        //Setting Product and Recommendation Attributes
                        foreach (var item in entry.product)
                        {
                            foreach (KeyValuePair<string, string> attr in valueAttrList)
                            {
                                if (item == attr.Key)
                                {
                                    prodList.Add(String.Join("=", attr.Value, item));
                                }
                            }
                        }
                        foreach (var item in entry.recommends)
                        {
                            foreach (KeyValuePair<string, string> attr in valueAttrList)
                            {
                                if (item == attr.Key)
                                {
                                    recommendationList.Add(String.Join("=", attr.Value, item));
                                }
                            }
                        }
                        string finalProducts = string.Join(" ", prodList);
                        file.WriteLine("Rule #{0} [Support : {1}, Confidence {2}]", rulecount, entry.support, entry.confidence);
                        string finalRecommeded = string.Join(" ", recommendationList);
                        file.WriteLine("[{0} --> {1}]\n", finalProducts, finalRecommeded);
                    }
                }                             
                file.WriteLine("Total Rules Generated : {0}", rulecount);
                file.WriteLine("Total Time taken : {0}", Time);
            }
        }

        /// <summary>
        /// This method is used to get subset of all Frequent itemset
        /// Referred from : http://stackoverflow.com/questions/999050/how-to-get-all-subsets-of-an-array 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="set"></param>
        /// <returns></returns>
        public static IEnumerable<IEnumerable<T>> GetSubsets<T>(IList<T> set)
        {
            var state = new BitArray(set.Count);
            do
                yield return Enumerable.Range(0, state.Count)
                                       .Select(i => state[i] ? set[i] : default(T));
            while (Increment(state));
        }

        /// <summary>
        /// This method used to increment the state of the parent
        /// Referred from : http://stackoverflow.com/questions/999050/how-to-get-all-subsets-of-an-array 
        /// </summary>
        /// <param name="flags"></param>
        /// <returns></returns>
        static bool Increment(BitArray flags)
        {
            int x = flags.Count - 1;
            while (x >= 0 && flags[x]) flags[x--] = false;
            if (x >= 0) flags[x] = true;
            return x >= 0;
        }

    }

    #endregion

    #region Models
    /// <summary>
    /// Model class of Datarows
    /// </summary>
    public class DataRows
    {
        public DataRows(string Id, string AttributeName, string ValueName)
        {
            this.Id = Id;
            this.AttributeName = AttributeName;
            this.ValueName = ValueName;
        }
        // Id of the Item
        public string Id;

        //Attribute Name of the Item
        public string AttributeName;

        //Item Name
        public string ValueName;
    }

    /// <summary>
    /// Model class of list of datrows
    /// </summary>
    public class Itemset
    {
        //List of DataRows      
        public List<DataRows> Item;
    }

    /// <summary>
    /// Model class of ResultClass
    /// </summary>
    public class ResultClass
    {
        //store support count            
        public double support;

        //store confidence rate
        public double confidence;

        //List of {S}
        public List<string> product;

        //List of {I-S}
        public List<string> recommends;
    }
    #endregion
}
